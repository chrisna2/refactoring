package code.refactoring.classmove_1;

public class AccountType {

	public boolean isPremium() {
		// TODO Auto-generated method stub
		return true;
	}

}
