package code.refactoring.methodsimple_7;

public class BalancedException extends Exception {
	
	public BalancedException() {
		super("BalancedException");
	}

}
