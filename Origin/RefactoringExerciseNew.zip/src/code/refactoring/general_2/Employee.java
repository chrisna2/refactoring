package code.refactoring.general_2;

public class Employee {

	private int _rate;
	
	public Employee(int rate) {
		_rate = rate;
	}
	public int getRate() {
		return 0;
	}

}
