package code.refactoring.general_4;

public class MemberInfoTest {

	public static void main(String[] args) {

		MemberInfoImpl memberInfo = new MemberInfoImpl();
		memberInfo.searchInform("ȫ���", "010-1234-5678");
		memberInfo.runService(11, 100);		
	}
}
