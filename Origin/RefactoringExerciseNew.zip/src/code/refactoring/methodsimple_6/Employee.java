package code.refactoring.methodsimple_6;

public class Employee {

	   private int _type;

	   public Employee (int type) {
	       _type = type;
    
	   }
   
}
