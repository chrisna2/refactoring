package code.refactoring.methodsimple_6;

public class Manager extends Employee {

	public Manager(int type) {
		super(type);
		System.out.println("Manager create --> ");
	}

}
