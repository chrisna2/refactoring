package code.refactoring.methodsimple_6;

public class Salesman extends Employee {

	public Salesman(int type) {
		super(type);
		System.out.println("Salesman create --> ");
	}

}
