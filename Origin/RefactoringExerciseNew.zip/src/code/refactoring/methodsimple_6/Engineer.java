package code.refactoring.methodsimple_6;

public class Engineer extends Employee {

	public Engineer(int type) {
		super(type);
		System.out.println("Engineer create --> ");
	}

}
