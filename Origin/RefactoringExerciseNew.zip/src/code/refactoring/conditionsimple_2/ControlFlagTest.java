package code.refactoring.conditionsimple_2;

public class ControlFlagTest {
	
	public static void main(String[] args) {
		
		ControlFlag cFlag = new ControlFlag();
		String[] people = {"Test", "Kim", "Don", "John"};
		cFlag.checkSecurity(people);

	} 
}
