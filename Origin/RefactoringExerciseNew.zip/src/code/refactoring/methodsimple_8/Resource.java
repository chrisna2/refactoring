package code.refactoring.methodsimple_8;

public class Resource {
	int num=0;

}
