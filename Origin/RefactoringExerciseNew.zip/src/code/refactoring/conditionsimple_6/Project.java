package code.refactoring.conditionsimple_6;

public class Project {
	public double getMemberExpenseLimit(){ 
		return 100; 
	}
}
