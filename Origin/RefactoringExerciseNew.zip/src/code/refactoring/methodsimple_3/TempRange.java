package code.refactoring.methodsimple_3;

public class TempRange {
	int getLow(){  return 10; }
	int getHigh(){ return 90; }

}
