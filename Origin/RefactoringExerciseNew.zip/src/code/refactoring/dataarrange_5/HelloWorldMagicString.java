package code.refactoring.dataarrange_5;

public class HelloWorldMagicString {

    public static void main(String[] args) {
        System.out.println("Hello World");

    }

}
