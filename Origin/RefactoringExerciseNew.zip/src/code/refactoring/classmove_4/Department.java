package code.refactoring.classmove_4;

public class Department {

    //private Person _manager ;
	private String departmentCode = "111";

    public Department () {
        //_manager = manager;
    	//departmentCode = code;
    }

    public String getManager() {
        return departmentCode;
    }
}
