package code.refactoring.methodarrange_1;

public class Order {
	int money ;
	Order(int money){
		this.money=money;
	}
	int getAmount(){
		return money;
	}
}
