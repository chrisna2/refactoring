package code.refactoring.classmove_2;

public class AccountType {
	private double _interestRate = 4.53;

	public double get_interestRate() {
		return _interestRate;
	}

	public void set_interestRate(double _interestRate) {
		this._interestRate = _interestRate;
	}

	public AccountType() {
		
	}
}
