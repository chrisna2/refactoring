package code.refactoring.general_1;

public class Employee {
	
	protected String _name;
	protected String _id;
	
	boolean isPriviliged() {
		return false;
		
	}
	
	void assignCar() {
		
	}

}
